A Pen created at CodePen.io. You can find this one at https://codepen.io/louwjlab/pen/prxwGo.

 World Choropleth Map - Robinson Projection 2010 with Plotly.js.